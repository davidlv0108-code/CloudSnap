// ============================================================
// 推送通知服务 - Firebase Cloud Messaging
// ============================================================

const config = require('../config');

let admin = null;

async function initFirebase() {
  if (!config.firebase.projectId) {
    console.warn('[推送] ⚠️ Firebase 未配置');
    return;
  }

  // [待填写] 初始化 Firebase Admin SDK
  // const admin = require('firebase-admin');
  // admin.initializeApp({
  //   credential: admin.credential.cert({
  //     projectId: config.firebase.projectId,
  //     privateKey: config.firebase.privateKey,
  //     clientEmail: config.firebase.clientEmail,
  //   }),
  // });
  console.log('[推送] Firebase 已初始化');
}

// ===== 发送推送通知 =====
async function sendPushNotification(token, title, body, data = {}) {
  if (!admin) {
    console.warn('[推送] Firebase 未初始化，跳过推送');
    return;
  }

  // [待填写] 实现推送
  // const message = {
  //   token,
  //   notification: { title, body },
  //   data,
  //   android: { notification: { channelId: 'cloudsnap_channel' } },
  //   apns: { payload: { aps: { badge: 1, sound: 'default' } } },
  // };
  // await admin.messaging().send(message);
}

module.exports = { initFirebase, sendPushNotification };
