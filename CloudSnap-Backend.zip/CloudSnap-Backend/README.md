# CloudSnap 后端系统

## 📦 项目结构

```
CloudSnap-Backend/
├── src/
│   ├── app.js                    # 服务器入口
│   ├── config/
│   │   └── index.js             # ⚠️ 配置文件（所有待填写项在此）
│   ├── routes/                   # API 路由
│   │   ├── index.js             # 路由入口
│   │   ├── auth.js              # 认证（注册/登录/社交登录）
│   │   ├── photos.js            # 照片（上传/查看/删除）
│   │   ├── sessions.js          # 会话（拍摄会话管理）
│   │   ├── friends.js           # 好友（搜索/请求/列表）
│   │   ├── ai.js                # AI（人脸识别/场景识别）
│   │   ├── billing.js           # 支付（订阅管理）
│   │   ├── push.js              # 推送（通知）
│   │   └── user.js              # 用户（资料/存储）
│   ├── services/                 # 服务层
│   │   ├── index.js             # 服务初始化
│   │   ├── database.js          # 数据库（Prisma）
│   │   ├── storage.js          # 文件存储（本地/S3）
│   │   ├── ai.js                # AI 服务（百度AI）
│   │   ├── firebase.js         # 推送服务（FCM）
│   │   ├── redis.js            # 缓存服务（Redis）
│   │   └── scheduler.js        # 定时任务
│   └── middleware/               # 中间件
│       ├── auth.js              # JWT 认证
│       ├── errorHandler.js      # 错误处理
│       └── logger.js            # 请求日志
├── prisma/
│   └── schema.prisma            # 数据库模型
├── .env.example                  # 环境变量模板
├── package.json
└── README.md
```

## ⚠️ 需要你填写的配置

### 1. 环境变量（.env 文件）

复制 `.env.example` 为 `.env`，填写以下内容：

| 配置项 | 说明 | 示例 |
|--------|------|------|
| `DATABASE_URL` | PostgreSQL 连接 | `postgresql://user:pass@localhost:5432/cloudsnap` |
| `JWT_SECRET` | JWT密钥 | `openssl rand -hex 32` 生成 |
| `CORS_ORIGINS` | 允许的前端域名 | `http://localhost:3000` |
| `UPLOAD_DIR` | 照片存储路径 | `C:\Users\PC\Desktop\照片` |
| `REDIS_URL` | Redis连接（可选） | `redis://localhost:6379` |
| `FIREBASE_*` | Firebase配置（可选） | 推送通知 |
| `BAIDU_*` | 百度AI配置（可选） | 人脸识别 |
| `GAODE_*` | 高德地图配置（可选） | 地点识别 |
| `WECHAT_*` | 微信登录（可选） | 社交登录 |
| `GOOGLE_*` | Google登录（可选） | 社交登录 |
| `APPLE_*` | Apple登录（可选） | 社交登录 |
| `ALIYUN_SMS_*` | 阿里云短信（可选） | 验证码 |
| `SMTP_*` | 邮件配置（可选） | 邮件通知 |

### 2. 配置文件（src/config/index.js）

所有标注 `[待填写]` 的项需要你填写。

## 🚀 启动步骤

```bash
# 1. 安装依赖
npm install

# 2. 配置环境变量
cp .env.example .env
# 编辑 .env 填写配置

# 3. 初始化数据库
npx prisma db push

# 4. 启动服务器
npm start

# 开发模式（自动重启）
npm run dev
```

## 📋 API 列表

### 认证
- `POST /api/auth/register` - 注册
- `POST /api/auth/login` - 登录
- `POST /api/auth/wechat` - 微信登录 [待配置]
- `POST /api/auth/google` - Google登录 [待配置]
- `POST /api/auth/apple` - Apple登录 [待配置]
- `POST /api/auth/send-sms` - 发送验证码 [待配置]

### 照片
- `POST /api/photos/upload` - 上传照片（带AI筛选）
- `GET /api/photos` - 获取照片列表
- `GET /api/photos/:id` - 获取照片详情
- `PATCH /api/photos/:id/favorite` - 收藏/取消
- `DELETE /api/photos/:id` - 删除照片

### 会话
- `POST /api/sessions` - 创建会话
- `GET /api/sessions` - 获取会话列表
- `POST /api/sessions/:id/invite` - 生成邀请码
- `POST /api/sessions/join` - 加入会话

### 好友
- `GET /api/friends/search` - 搜索用户
- `POST /api/friends/request` - 发送好友请求
- `POST /api/friends/accept/:id` - 接受请求
- `GET /api/friends` - 好友列表
- `GET /api/friends/requests` - 待处理请求
- `DELETE /api/friends/:id` - 删除好友

### AI
- `POST /api/ai/analyze` - 分析照片
- `GET /api/ai/faces` - 人脸分组
- `PUT /api/ai/faces/:id` - 重命名人脸
- `GET /api/ai/locations` - 地点分组
- `POST /api/ai/register-face` - 注册人脸

### 支付
- `GET /api/billing/plans` - 获取方案
- `POST /api/billing/sync` - 同步订阅
- `POST /api/billing/restore` - 恢复购买

### 推送
- `POST /api/push/register` - 注册推送Token
- `POST /api/push/test` - 发送测试通知

### 用户
- `GET /api/user/profile` - 获取资料
- `PATCH /api/user/profile` - 更新资料
- `GET /api/user/storage` - 存储使用情况
- `DELETE /api/user/account` - 删除账户 [待实现]
